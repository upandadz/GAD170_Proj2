using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = System.Object;

public class FloorDestroyer : MonoBehaviour
{
    private GameObject floor;

    private void Start()
    {
        // get refence to floor prefab
    }

    void OnTriggerEnter(Collider Player)
    {
        //destroy prefab
    }
}
