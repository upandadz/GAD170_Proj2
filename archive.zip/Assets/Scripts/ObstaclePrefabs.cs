using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaclePrefabs : MonoBehaviour
{
    public GameObject prefabOne;
    public GameObject prefabTwo;
    public GameObject prefabThree;
}
